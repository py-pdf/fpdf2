"""This package contains error tests"""
